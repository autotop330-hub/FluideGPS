/* Fluide 2.8 — actual screen interactions. Does not replace route or EV engines. */
(() => {
  "use strict";
  function refreshHome(){
    const m=document.getElementById("evHomeModel");
    const b=document.getElementById("evHomeSoc");
    if (m && typeof Tesla!=="undefined") m.textContent = Tesla.model().name;
    if (b && typeof Tesla!=="undefined") b.textContent = Tesla.soc()+" %";
  }
  const startEV=document.getElementById("evHomeBtn");
  if(startEV) startEV.addEventListener("click", () => {
    S.prefs.tesla=true;
    save.prefs();
    refreshHome();
    Search.open();
    const q=document.getElementById("q");
    if(q) q.placeholder="Destination de votre trajet électrique…";
  });
  const origOpenSettings=document.getElementById("openSettings");
  if(origOpenSettings) origOpenSettings.addEventListener("click", () => {
    // Existing settings handler owns navigation and rendering; no override.
  });
  document.addEventListener("change", e => {
    if (e.target.id === "evQuickModel" || e.target.id === "evQuickReserve") {
      if(e.target.id==="evQuickModel") S.prefs.teslaModel=e.target.value;
      else S.prefs.reserve=Number(e.target.value);
      save.prefs();
      if(Plan.routes){
        Plan.routes.forEach(r=>{ r.tesla=null; r.teslaData=null; });
        Plan.render();
        Plan.teslaFor();
      }
      refreshHome();
      return;
    }
    if(["teslaModel","vehicle"].includes(e.target.id)) setTimeout(refreshHome,0);
    if(e.target.id==="socRange") refreshHome();
  });
  document.addEventListener("input", e => {
    if(e.target.id==="socRange") {
      e.target.style.setProperty("--soc",e.target.value+"%");
      const b=document.getElementById("tzSoc"); if(b) b.textContent=e.target.value+" %";
      refreshHome();
    }
  });
  const observer=new MutationObserver(() => {
    if(document.body.dataset.mode==="idle") refreshHome();
  });
  observer.observe(document.body,{attributes:true,attributeFilter:["data-mode"]});
  refreshHome();
})();
