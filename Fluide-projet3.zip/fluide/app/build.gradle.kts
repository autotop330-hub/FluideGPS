plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "fr.fluide"
    compileSdk = 34

    defaultConfig {
        applicationId = "fr.fluide.gps"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }

    // Même clé à chaque compilation : les mises à jour s'installent par-dessus sans désinstaller.
    signingConfigs {
        create("perso") {
            storeFile = file("fluide.keystore")
            storePassword = "fluide1234"
            keyAlias = "fluide"
            keyPassword = "fluide1234"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("perso") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("perso")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // Les contrôles de style ne doivent pas bloquer la fabrication de l'appli
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // Sert l'appli depuis une adresse https interne (localisation et stockage fiables)
    implementation("androidx.webkit:webkit:1.11.0")
}
