/* Fluide 2.9: progressive disclosure and live EV summary.
   Navigation, battery calculation and mapping are still the original engines. */
(() => {
  'use strict';
  const q = document.getElementById('quickToggle');
  if (q) q.addEventListener('click', () => {
    const opened = document.body.classList.toggle('quick-open');
    q.setAttribute('aria-expanded',String(opened));
    if (typeof measureDock === 'function') measureDock();
  });
  const more = document.getElementById('navDetailsBtn');
  if (more) more.addEventListener('click', () => {
    const panel = document.getElementById('navBottom');
    const opened = panel.classList.toggle('nav-expanded');
    more.setAttribute('aria-expanded',String(opened));
    more.setAttribute('aria-label',opened?'Masquer les détails de navigation':'Afficher les détails de navigation');
    try { if(typeof Nav!=='undefined' && Nav.on && typeof Nav.camera==='function') Nav.camera(); }catch(e){}
  });
  const lite = window.FluideLite = {
    evExpanded: false,
    syncEV(rt){
      if(!rt || !rt.tesla) return;
      const dest = document.getElementById('evBriefText');
      if(!dest || typeof Plan==='undefined' || Plan.sel!==rt.id) return;
      const t=rt.tesla, arr=isFinite(t.arrival)?Math.round(t.arrival)+' %':'—';
      const stops=t.stops.length;
      const charge = stops && isFinite(t.chargeMin) ? ' · +'+fmtDurStr(t.chargeMin*60):'';
      dest.textContent=arr+' à l’arrivée · '+stops+' recharge'+(stops>1?'s':'')+charge;
    }
  };
  // Details in a dynamically re-rendered route sheet: persist expanded state.
  document.addEventListener('toggle',e=>{
    if(e.target && e.target.id==='evDetails') lite.evExpanded=e.target.open;
  },true);
  // After a mode transition, dismiss map-only auxiliary controls.
  const modeObserver=new MutationObserver(()=>{
    if(document.body.dataset.mode !=='nav'){
      const el=document.getElementById('navBottom');
      if(el) el.classList.remove('nav-expanded');
      if(more) more.setAttribute('aria-expanded','false');
    }
  });
  modeObserver.observe(document.body,{attributes:true,attributeFilter:['data-mode']});
})();
