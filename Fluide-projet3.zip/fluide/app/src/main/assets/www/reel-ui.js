/* Fluide 2.8 — actual screen interactions. Does not replace route or EV engines. */
(() => {
  "use strict";
  function refreshHome(){
    const m=document.getElementById("evHomeModel");
    const b=document.getElementById("evHomeSoc");
    if (m && typeof Tesla!=="undefined") {
      const model=Tesla.model().name;
      m.textContent = model.match(/Model\s+[Y3SXP]/i)?.[0] || model;
      m.title = model; // Le modèle complet reste accessible dans les détails du trajet.
    }
    if (b && typeof Tesla!=="undefined") {
      b.textContent = Tesla.soc()+" %";
      const lab=b.nextElementSibling;
      if(lab) lab.textContent = (typeof Car!=="undefined" && Car.fresh() && !S.socManual) ? "Batterie réelle · "+Car.ageTxt() : (typeof Car!=="undefined" && Car.on() ? "Tesla connectée" : "Batterie saisie");
    }
    // pastille batterie dans la barre de recherche
    const sb=document.getElementById("sbBatt");
    if(sb && typeof Tesla!=="undefined"){
      const on=Tesla.on(), live=typeof Car!=="undefined" && Car.fresh();
      sb.hidden=!on;
      if(on) sb.innerHTML=(live?'<i class="live">●</i>':'')+'<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M13 2 4 14h6l-1 8 9-12h-6z"/></svg>'+(live?Car.live.soc:Tesla.soc())+' %';
      sb.title = live ? "Batterie réelle · "+Car.ageTxt() : "Batterie saisie";
    }
  }
  const sbB=document.getElementById("sbBatt");
  if(sbB) sbB.addEventListener("click", e=>{ e.stopPropagation(); if(typeof Car!=="undefined" && Car.on()) Car.refresh(true).then(refreshHome); else { const o=document.getElementById("openSettings"); if(o) o.click(); } });
  const startEV=document.getElementById("evHomeBtn");
  if(startEV) startEV.addEventListener("click", () => {
    S.prefs.tesla=true;
    save.prefs();
    refreshHome();
    Search.open();
    const q=document.getElementById("q");
    if(q) q.placeholder="Destination de votre trajet électrique…";
  });
  const origOpenSettings=document.getElementById("openSettings");
  if(origOpenSettings) origOpenSettings.addEventListener("click", () => {
    // Existing settings handler owns navigation and rendering; no override.
  });
  document.addEventListener("change", e => {
    if (e.target.id === "evQuickModel" || e.target.id === "evQuickReserve") {
      if(e.target.id==="evQuickModel") S.prefs.teslaModel=e.target.value;
      else S.prefs.reserve=Number(e.target.value);
      save.prefs();
      if(Plan.routes){
        Plan.routes.forEach(r=>{ r.tesla=null; r.teslaData=null; });
        Plan.render();
        Plan.teslaFor();
      }
      refreshHome();
      return;
    }
    if(["teslaModel","vehicle"].includes(e.target.id)) setTimeout(refreshHome,0);
    if(e.target.id==="socRange") refreshHome();
  });
  document.addEventListener("input", e => {
    if(e.target.id==="socRange") {
      e.target.style.setProperty("--soc",e.target.value+"%");
      const b=document.getElementById("tzSoc"); if(b) b.textContent=e.target.value+" %";
      refreshHome();
    }
  });
  // Tesla connectée (Teslemetry) : relit la vraie batterie en revenant à l'accueil
  function liveHome(){ if(typeof Car!=="undefined" && Car.on()) Car.refresh().then(refreshHome); }
  const observer=new MutationObserver(() => {
    if(document.body.dataset.mode==="idle"){ refreshHome(); liveHome(); }
  });
  setTimeout(liveHome, 2500);
  observer.observe(document.body,{attributes:true,attributeFilter:["data-mode"]});
  refreshHome();
})();
