/* FLUIDE PREMIUM — fonction de vue 2D/3D, indépendante de la navigation.
   Respecte les préférences enregistrées et se désactive visuellement en guidage. */
(() => {
  "use strict";
  const btn = document.getElementById("perspectiveBtn");
  const label = document.getElementById("perspectiveLabel");
  if (!btn || !label) return;
  const current = () => S.prefs.view3d === true;
  function updateButton() {
    const enabled = current();
    btn.setAttribute("aria-pressed", String(enabled));
    btn.setAttribute("aria-label", enabled ? "Revenir à la carte 2D" : "Activer la vue 3D");
    label.textContent = enabled ? "Vue 3D" : "Vue 2D";
    btn.title = enabled ? "Vue 3D activée — toucher pour revenir en 2D" : "Vue 2D activée — toucher pour passer en 3D";
  }
  btn.addEventListener("click", () => {
    if (typeof map === "undefined" || !map || document.body.dataset.mode !== "idle") return;
    S.prefs.view3d = !current();
    save.prefs();
    updateButton();
    const enabled = current();
    try {
      map.easeTo({pitch: enabled ? 55 : 0,
        zoom:enabled ? Math.max(map.getZoom(),15.25) : map.getZoom(),
        duration:850,
        easing:t => 1-Math.pow(1-t,3)});
    } catch (e) { console.warn("Vue 3D indisponible",e); }
  });
  updateButton();
  // La carte est initialisée async : restore the preference without blocking map load.
  let attempts = 0;
  const it = setInterval(() => {
    if (typeof map !== "undefined" && map && map.loaded()) {
      clearInterval(it);
      if (current() && document.body.dataset.mode === "idle") {
        try { map.easeTo({pitch:55,zoom:Math.max(map.getZoom(),15.25),duration:900}); } catch(e){}
      }
    } else if (++attempts > 30) clearInterval(it);
  }, 500);
})();
