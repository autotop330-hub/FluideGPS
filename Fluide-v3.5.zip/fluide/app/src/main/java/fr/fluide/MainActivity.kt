package fr.fluide

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Fluide : la carte, les itinéraires et la navigation tournent dans une page web
 * embarquée (assets/www). Cette activité lui donne ce qu'un navigateur n'a pas :
 * la voix du téléphone, l'écran qui reste allumé, le GPS et le bouton retour.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var utterance = 0

    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val host = "appassets.androidplatform.net"
    private val startUrl = "https://$host/assets/www/index.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val loader = WebViewAssetLoader.Builder()
            .setDomain(host)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#090C11"))
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            textZoom = 100
            userAgentString = "$userAgentString FluideApp/1.0"
        }

        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == host) return false
                // Liens externes (inscription TomTom, data.gouv…) : navigateur du téléphone
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
                } catch (e: Exception) { true }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                if (hasLocation()) {
                    callback?.invoke(origin, true, false)
                } else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    askLocation()
                }
            }

            override fun onShowFileChooser(
                webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(intent, "Fichier CSV"), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.FRANCE)
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts?.setSpeechRate(1.05f)
                ttsReady = true
            }
        }

        if (!hasLocation()) askLocation()
        web.loadUrl(startUrl)
    }

    private fun hasLocation() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun askLocation() {
        requestPermissions(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            REQ_LOCATION
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_LOCATION) return
        val ok = hasLocation()
        pendingGeoCallback?.invoke(pendingGeoOrigin, ok, false)
        pendingGeoCallback = null
        pendingGeoOrigin = null
        // La page relance la localisation dès que l'autorisation est donnée
        if (ok) web.evaluateJavascript(
            "if(typeof Geo!=='undefined' && !S.demo){ if(Geo.watch!=null){ navigator.geolocation.clearWatch(Geo.watch); Geo.watch=null; } Geo.start(); }",
            null
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.fluideBack ? window.fluideBack() : false") { r ->
            if (r != "true") finish()
        }
    }

    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }

    /** Fonctions appelées depuis la page (window.Android). */
    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String) {
            if (!ttsReady) return
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "fluide-${utterance++}")
        }

        @JavascriptInterface
        fun stopSpeaking() { tts?.stop() }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        /** Barres du téléphone assorties au thème de la carte (jour clair, nuit sombre). */
        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun setDay(day: Boolean) {
            runOnUiThread {
                window.statusBarColor = Color.parseColor(if (day) "#EDF1F6" else "#070A10")
                window.navigationBarColor = Color.parseColor(if (day) "#FFFFFF" else "#0C1119")
                web.setBackgroundColor(Color.parseColor(if (day) "#EDF1F6" else "#070A10"))
                val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                val f = window.decorView.systemUiVisibility
                window.decorView.systemUiVisibility = if (day) f or light else f and light.inv()
            }
        }

        /** Requête web faite par l'appli (Teslemetry…) : pas de blocage CORS du navigateur. */
        @JavascriptInterface
        fun http(id: String, method: String, url: String, headers: String, body: String) {
            Thread {
                var code = 0
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = method
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    val h = JSONObject(if (headers.isEmpty()) "{}" else headers)
                    h.keys().forEach { k -> c.setRequestProperty(k, h.getString(k)) }
                    if (body.isNotEmpty() && method != "GET") {
                        c.doOutput = true
                        c.outputStream.use { it.write(body.toByteArray()) }
                    }
                    code = c.responseCode
                    val st = if (code >= 400) c.errorStream else c.inputStream
                    text = st?.bufferedReader()?.use { it.readText() } ?: ""
                    c.disconnect()
                } catch (e: Exception) {
                    code = 0; text = ""
                }
                val js = "window.__http && window.__http(" + JSONObject.quote(id) + "," + code + "," + JSONObject.quote(text) + ")"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }.start()
        }

        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Fluide", text))
            }
        }
    }

    companion object {
        private const val REQ_LOCATION = 1
        private const val REQ_FILE = 2
    }
}
